const express = require('express');
const path =require('path');
const hbs =require('hbs');
const app =express();
const port =process.env.PORT || 3000;
// pbulic static path
const static_path =path.join(__dirname, "../public");

// app.set('views', path.join(__dirname, '../views')); 
// const templates = path.join(__dirname,'../views');
// const templates = path.join(__dirname,'../templates/views');
const templates = path.join(__dirname,'../templates/views');
const partials_path = path.join(__dirname,'../templates/partials');
// views engine
app.set('view engine', 'hbs');
app.set('views', templates );
hbs.registerPartials(partials_path);
app.use(express.static(static_path));

// page coding
app.get("", (req, res) => {

res.render('index');

});
app.get("/about", (req, res) => {

res.render('about');

});
app.get("/weather", (req, res) => {

res.render("weather");

});
app.get("*", (req, res) => {

res.render("404error");
errorMsg:'Opps! page Not Found';
});




// server decler
app.listen(port, () => {
console.log(`listening port 8000 ${port}`);
})















